/*
Bryan Vasquez
Vasquez_a02b.js
INFO 2124
Thoendel
12/15/2019
*/
let firtsName = "Bryan Vasquez";
var age = 23;
const hairColor = "Black";
const eyeColor = "Brown";
 console.log("About me v.1.0");
 console.log("===============");
 console.log("My name: " + firtsName);
 console.log("My age: " + age);
 console.log("My hair color: " + hairColor);
 console.log("My eye color: " + eyeColor);
